﻿namespace MVCTravelBookingISE.Data.ViewComponents
{
    public class SharedViewModel
    {
    }
}
