﻿namespace MVCTravelBookingISE.Data.Base
{
    public interface IEntityBase
    {
        public int Id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
