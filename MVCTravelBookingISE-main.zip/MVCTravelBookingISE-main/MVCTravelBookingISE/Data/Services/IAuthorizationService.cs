using MVCTravelBookingISE.Data.Base;
using MVCTravelBookingISE.Models;


namespace MVCTravelBookingISE.Data.Services
{
    public interface IAuthorizationService:IEntityBaseRepository<AccomodationModel>
    {

    }

   
}
