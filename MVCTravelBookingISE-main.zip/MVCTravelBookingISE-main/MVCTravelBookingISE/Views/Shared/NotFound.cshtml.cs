using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MVCTravelBookingISE.Views.Shared
{
    public class NotFoundModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
