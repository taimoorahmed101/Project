﻿using System;
using System.Collections.Generic;

namespace FlightBooking.Models
{
    public partial class FbookingDestMstPs
    {
        public int DestinationId { get; set; }
        public string DestinationCode { get; set; }
        public string Description { get; set; }
    }
}
